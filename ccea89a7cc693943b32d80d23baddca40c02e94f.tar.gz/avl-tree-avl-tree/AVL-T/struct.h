#ifndef STRUCT_H
#define STRUCT_H

class struct
{
public:
    struct();
};

#endif // STRUCT_H
